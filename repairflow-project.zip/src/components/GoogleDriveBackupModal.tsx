import React, { useState, useEffect } from 'react';
import {
  FolderArchive,
  CloudUpload,
  CheckCircle2,
  ExternalLink,
  RefreshCw,
  FileText,
  X,
  AlertCircle,
  HardDrive,
  Download,
  RotateCcw,
  ShieldCheck,
  LogOut,
  FolderOpen,
} from 'lucide-react';
import {
  DEFAULT_DRIVE_FOLDER_ID,
  DEFAULT_DRIVE_FOLDER_URL,
  uploadJsonBackupToDrive,
  uploadZipArchiveToDrive,
  listFilesInDriveFolder,
  downloadFileContentFromDrive,
  DriveFileItem,
} from '../utils/googleDriveBackup';
import {
  auth,
  signInWithGoogleWithDrive,
  getCachedAccessToken,
  signOut,
  onAuthStateChanged,
  User,
} from '../firebase';
import { ConfirmDeleteModal } from './ConfirmDeleteModal';

interface GoogleDriveBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'gu' | 'en';
  currentData: {
    invoices: any[];
    catalog: any[];
    customers: any[];
    payments: any[];
    purchases: any[];
    expenses: any[];
    settings: any;
    unitMasters: any[];
    suppliers: any[];
  };
  onRestoreData: (restoredData: any) => void;
}

export const GoogleDriveBackupModal: React.FC<GoogleDriveBackupModalProps> = ({
  isOpen,
  onClose,
  lang,
  currentData,
  onRestoreData,
}) => {
  const [currentUser, setCurrentUser] = useState<User | null>(auth.currentUser);
  const [accessToken, setAccessToken] = useState<string | null>(getCachedAccessToken());
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [isUploadingData, setIsUploadingData] = useState(false);
  const [isUploadingZip, setIsUploadingZip] = useState(false);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [driveFiles, setDriveFiles] = useState<DriveFileItem[]>([]);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Restore confirmation state
  const [fileToRestore, setFileToRestore] = useState<DriveFileItem | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      const token = getCachedAccessToken();
      setAccessToken(token);
      if (user && token && isOpen) {
        loadFolderFiles(token);
      }
    });
    return () => unsub();
  }, [isOpen]);

  useEffect(() => {
    if (isOpen && accessToken) {
      loadFolderFiles(accessToken);
    }
  }, [isOpen, accessToken]);

  if (!isOpen) return null;

  const handleSignIn = async () => {
    try {
      setIsAuthenticating(true);
      setStatusMessage(null);
      const result = await signInWithGoogleWithDrive();
      setCurrentUser(result.user);
      setAccessToken(result.accessToken);
      setStatusMessage({
        type: 'success',
        text: lang === 'gu' ? 'ગુગલ ડ્રાઇવ સાથે સફળતાપૂર્વક જોડાયું!' : 'Connected to Google Drive successfully!',
      });
      loadFolderFiles(result.accessToken);
    } catch (err: any) {
      console.warn('Google Drive sign-in result:', err);
      const errorCode = err?.code || '';
      if (errorCode === 'auth/popup-closed-by-user') {
        setStatusMessage({
          type: 'error',
          text:
            lang === 'gu'
              ? 'સાઇન-ઇન પોપઅપ વિન્ડો બંધ થઈ ગઈ હતી. ફરી પ્રયાસ કરવા માટે "Google સાથે સાઇન ઇન કરો" પર ક્લિક કરો.'
              : 'Sign-in window was closed before completion. Please click "Sign in with Google" again to connect.',
        });
      } else if (errorCode === 'auth/cancelled-popup-request') {
        setStatusMessage({
          type: 'error',
          text:
            lang === 'gu'
              ? 'બીજી સાઇન-ઇન વિનંતી શરૂ થઈ હોવાથી આ રદ થઈ હતી. કૃપા કરીને ફરી પ્રયાસ કરો.'
              : 'Sign-in attempt was replaced by another request. Please try again.',
        });
      } else if (errorCode === 'auth/popup-blocked') {
        setStatusMessage({
          type: 'error',
          text:
            lang === 'gu'
              ? 'બ્રાઉઝરે પોપઅપ વિન્ડો બ્લોક કરી દીધી છે. કૃપા કરીને પોપઅપને મંજૂરી આપો.'
              : 'Pop-up window was blocked by your browser. Please allow popups for this site and retry.',
        });
      } else {
        setStatusMessage({
          type: 'error',
          text:
            err.message ||
            (lang === 'gu' ? 'ગુગલ ડ્રાઇવ સાથે જોડાવામાં ભૂલ થઈ.' : 'Authentication failed. Please try again.'),
        });
      }
    } finally {
      setIsAuthenticating(false);
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    setCurrentUser(null);
    setAccessToken(null);
    setDriveFiles([]);
  };

  const loadFolderFiles = async (token: string) => {
    try {
      setIsLoadingFiles(true);
      const files = await listFilesInDriveFolder(token);
      setDriveFiles(files);
    } catch (err: any) {
      console.warn('Could not list drive folder files:', err);
    } finally {
      setIsLoadingFiles(false);
    }
  };

  const handleBackupDatabase = async () => {
    if (!accessToken) {
      setStatusMessage({
        type: 'error',
        text: lang === 'gu' ? 'કૃપા કરીને પહેલા ગુગલ ડ્રાઇવ સાથે સાઇન ઇન કરો.' : 'Please sign in with Google first.',
      });
      return;
    }

    try {
      setIsUploadingData(true);
      setStatusMessage(null);
      const res = await uploadJsonBackupToDrive(currentData, accessToken);
      setStatusMessage({
        type: 'success',
        text: lang === 'gu'
          ? `ડેટા બેકઅપ સફળતાપૂર્વક ગૂગલ ડ્રાઇવ પર અપલોડ થયો: ${res.name}`
          : `Database backup uploaded to Drive: ${res.name}`,
      });
      loadFolderFiles(accessToken);
    } catch (err: any) {
      console.error('Drive backup error:', err);
      setStatusMessage({
        type: 'error',
        text: err.message || (lang === 'gu' ? 'બેકઅપ અપલોડ કરવામાં નિષ્ફળ.' : 'Failed to upload backup.'),
      });
    } finally {
      setIsUploadingData(false);
    }
  };

  const handleBackupCodeZip = async () => {
    if (!accessToken) {
      setStatusMessage({
        type: 'error',
        text: lang === 'gu' ? 'કૃપા કરીને પહેલા ગુગલ ડ્રાઇવ સાથે સાઇન ઇન કરો.' : 'Please sign in with Google first.',
      });
      return;
    }

    try {
      setIsUploadingZip(true);
      setStatusMessage(null);
      const res = await uploadZipArchiveToDrive(accessToken);
      setStatusMessage({
        type: 'success',
        text: lang === 'gu'
          ? `પ્રોજેક્ટ સોર્સ કોડ (.ZIP) ગૂગલ ડ્રાઇવ ફોલ્ડરમાં સચવાઈ ગયો: ${res.name}`
          : `Source code (.ZIP) saved to Google Drive: ${res.name}`,
      });
      loadFolderFiles(accessToken);
    } catch (err: any) {
      console.error('Drive zip backup error:', err);
      setStatusMessage({
        type: 'error',
        text: err.message || (lang === 'gu' ? 'સોર્સ કોડ અપલોડ કરવામાં નિષ્ફળ.' : 'Failed to upload source zip.'),
      });
    } finally {
      setIsUploadingZip(false);
    }
  };

  const confirmRestore = async () => {
    if (!fileToRestore || !accessToken) return;

    try {
      setIsRestoring(true);
      const backupJson = await downloadFileContentFromDrive(fileToRestore.id, accessToken);
      onRestoreData(backupJson);
      setStatusMessage({
        type: 'success',
        text: lang === 'gu'
          ? `બેકઅપ સફળતાપૂર્વક રિસ્ટોર કરવામાં આવ્યું: ${fileToRestore.name}`
          : `Data successfully restored from: ${fileToRestore.name}`,
      });
      setFileToRestore(null);
    } catch (err: any) {
      console.error('Restore error:', err);
      setStatusMessage({
        type: 'error',
        text: err.message || (lang === 'gu' ? 'રિસ્ટોર કરવામાં ભૂલ આવી.' : 'Failed to restore backup.'),
      });
    } finally {
      setIsRestoring(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-xs">
              <FolderArchive className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                {lang === 'gu' ? 'ગુગલ ડ્રાઇવ બેકઅપ & સેટઅપ' : 'Google Drive Backup & Setup'}
              </h3>
              <p className="text-xs text-emerald-100">
                {lang === 'gu'
                  ? 'તમારા પર્સનલ ગુગલ ડ્રાઇવ ફોલ્ડરમાં ડેટા અને સોર્સ કોડ સાચવો'
                  : 'Store live backups & codebase in your designated Google Drive folder'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Target Folder Link Banner */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5 uppercase tracking-wider">
                <FolderOpen className="w-4 h-4 text-emerald-600" />
                <span>{lang === 'gu' ? 'લક્ષિત ગુગલ ડ્રાઇવ ફોલ્ડર' : 'Designated Drive Folder'}</span>
              </span>
              <a
                href={DEFAULT_DRIVE_FOLDER_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-100 hover:bg-emerald-200 px-2.5 py-1 rounded-lg transition-colors"
              >
                <span>{lang === 'gu' ? 'ડ્રાઇવમાં ખોલો' : 'Open in Google Drive'}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <p className="text-xs text-slate-500 font-mono break-all">
              {DEFAULT_DRIVE_FOLDER_URL}
            </p>
          </div>

          {/* Auth Bar / Official Sign-in */}
          <div className="p-4 border border-slate-200 rounded-xl bg-white shadow-2xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-800">
                  {lang === 'gu' ? 'ગુગલ એકાઉન્ટ જોડાણ' : 'Google Account Authorization'}
                </span>
              </div>
              {currentUser && accessToken && (
                <div className="flex items-center gap-2">
                  <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-medium">
                    {currentUser.email}
                  </span>
                  <button
                    onClick={handleSignOut}
                    className="inline-flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 font-semibold px-2 py-0.5 rounded-md hover:bg-rose-50"
                  >
                    <LogOut className="w-3 h-3" />
                    <span>{lang === 'gu' ? 'ડિસ્કનેક્ટ' : 'Disconnect'}</span>
                  </button>
                </div>
              )}
            </div>

            {(!currentUser || !accessToken) && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                <p className="text-xs text-slate-600">
                  {lang === 'gu'
                    ? 'તમારા ગુગલ એકાઉન્ટ સાથે કનેક્ટ કરી આ ફોલ્ડરમાં બેકઅપ ફાઇલો સેવ કરવાની પરવાનગી આપો:'
                    : 'Connect with Google to allow saving backup snapshots and project zip files directly into your folder:'}
                </p>

                {/* Official Material Google Sign-in Button */}
                <button
                  type="button"
                  onClick={handleSignIn}
                  disabled={isAuthenticating}
                  className="inline-flex items-center justify-center gap-2.5 px-4 py-2 border border-slate-300 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-xs transition-colors shrink-0 disabled:opacity-50"
                >
                  <svg className="w-4 h-4" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                  </svg>
                  <span>{isAuthenticating ? (lang === 'gu' ? 'કનેક્ટ થઈ રહ્યું છે...' : 'Connecting...') : (lang === 'gu' ? 'Google સાથે સાઇન ઇન કરો' : 'Sign in with Google')}</span>
                </button>
              </div>
            )}
          </div>

          {/* Status Alert */}
          {statusMessage && (
            <div
              className={`p-3.5 rounded-xl text-xs flex items-center gap-2.5 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                  : 'bg-rose-50 text-rose-900 border border-rose-200'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span className="font-medium">{statusMessage.text}</span>
            </div>
          )}

          {/* Action Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Action 1: Upload Database JSON */}
            <div className="p-4 border border-slate-200 rounded-xl bg-slate-50/70 hover:bg-slate-50 transition-colors space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
                  <HardDrive className="w-4 h-4 text-indigo-600" />
                  <span>{lang === 'gu' ? '૧. સંપૂર્ણ ડેટાબેઝ બેકઅપ (.JSON)' : '1. Database Backup (.JSON)'}</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {lang === 'gu'
                    ? 'તમામ ઇન્વૉઇસ, ગ્રાહકો, સ્ટોક, ખર્ચ અને સેટિંગ્સની સ્નેપશોટ ફાઇલ ગૂગલ ડ્રાઇવ ફોલ્ડરમાં અપલોડ કરે છે.'
                    : 'Exports all invoices, catalog stock, customer ledger, and expenses to your Drive folder.'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleBackupDatabase}
                disabled={isUploadingData || !accessToken}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
              >
                <CloudUpload className="w-4 h-4" />
                <span>
                  {isUploadingData
                    ? (lang === 'gu' ? 'અપલોડ થઈ રહ્યું છે...' : 'Uploading...')
                    : (lang === 'gu' ? 'ડ્રાઇવ પર ડેટા બેકઅપ લો' : 'Backup Data to Drive')}
                </span>
              </button>
            </div>

            {/* Action 2: Upload Source Code ZIP */}
            <div className="p-4 border border-slate-200 rounded-xl bg-slate-50/70 hover:bg-slate-50 transition-colors space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
                  <FolderArchive className="w-4 h-4 text-emerald-600" />
                  <span>{lang === 'gu' ? '૨. સોર્સ કોડ ઝીપ ફાઇલ (.ZIP)' : '2. Source Code Archive (.ZIP)'}</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {lang === 'gu'
                    ? 'આ સોફ્ટવેરનો સંપૂર્ણ React & TypeScript સોર્સ કોડ તમારા ડ્રાઇવ ફોલ્ડરમાં સેવ કરો.'
                    : 'Uploads the complete ready-to-run source code zip archive into your Drive folder.'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleBackupCodeZip}
                disabled={isUploadingZip || !accessToken}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
              >
                <CloudUpload className="w-4 h-4" />
                <span>
                  {isUploadingZip
                    ? (lang === 'gu' ? 'અપલોડ થઈ રહ્યું છે...' : 'Uploading...')
                    : (lang === 'gu' ? 'કોડબેઝ (.ZIP) ડ્રાઇવ પર સાચવો' : 'Save Source Code to Drive')}
                </span>
              </button>
            </div>
          </div>

          {/* Files Currently in Drive Folder */}
          <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-600" />
                <span>{lang === 'gu' ? 'આ ફોલ્ડરમાં ઉપલબ્ધ ફાઇલો' : 'Files in this Google Drive Folder'}</span>
              </span>
              {accessToken && (
                <button
                  type="button"
                  onClick={() => loadFolderFiles(accessToken)}
                  disabled={isLoadingFiles}
                  className="p-1 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                  title="Refresh file list"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFiles ? 'animate-spin' : ''}`} />
                </button>
              )}
            </div>

            {isLoadingFiles ? (
              <div className="py-6 text-center text-xs text-slate-400">
                <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-1 text-indigo-500" />
                <span>{lang === 'gu' ? 'ફાઇલો લોડ થઈ રહી છે...' : 'Loading folder contents...'}</span>
              </div>
            ) : driveFiles.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-lg">
                <span>
                  {accessToken
                    ? (lang === 'gu' ? 'આ ફોલ્ડરમાં હજુ સુધી કોઈ બેકઅપ નથી. ઉપરનું બટન દબાવી પહેલો બેકઅપ લો.' : 'No backup files found in this folder yet. Click a button above to create one.')
                    : (lang === 'gu' ? 'ફાઇલો જોવા માટે ઉપર Google સાથે સાઇન ઇન કરો.' : 'Sign in with Google above to view files.')}
                </span>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto">
                {driveFiles.map((f) => (
                  <div key={f.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-slate-800 truncate flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{f.name}</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {new Date(f.createdTime).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {f.name.endsWith('.json') && (
                        <button
                          type="button"
                          onClick={() => setFileToRestore(f)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 rounded-lg transition-colors"
                          title="Restore data from this file"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>{lang === 'gu' ? 'રિસ્ટોર' : 'Restore'}</span>
                        </button>
                      )}

                      {f.webViewLink && (
                        <a
                          href={f.webViewLink}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-md transition-colors"
                          title="Open file in Drive"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Local Run & Deploy Guide via Google Drive */}
          <div className="p-4 bg-slate-900 text-slate-200 rounded-xl space-y-2 text-xs font-mono">
            <div className="font-bold text-emerald-400 font-sans flex items-center gap-2">
              <FolderArchive className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'gu' ? 'આ ગૂગલ ડ્રાઇવ ફોલ્ડરથી કમ્પ્યુટર પર કેવી રીતે ચલાવવું' : 'How to Run & Deploy from Google Drive'}</span>
            </div>
            <div className="text-slate-300 font-sans space-y-1.5 text-xs pl-2 border-l-2 border-emerald-500">
              <p>
                <strong>1. Google Drive for Desktop:</strong> Install the Google Drive desktop app so this folder syncs locally to your PC as a normal folder (e.g. <code>G:\My Drive\RepairFlow</code>).
              </p>
              <p>
                <strong>2. Run Locally:</strong> Open terminal in that folder and run:
              </p>
              <p className="font-mono text-emerald-400 bg-slate-950 p-1.5 rounded">
                npm install &amp;&amp; npm run dev
              </p>
              <p>
                <strong>3. Deploy anytime:</strong> Any code changes you make remain backed up in this Google Drive folder automatically!
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-end shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
          >
            {lang === 'gu' ? 'બંધ કરો' : 'Close'}
          </button>
        </div>
      </div>

      {/* Explicit User Confirmation for Restoring Data */}
      <ConfirmDeleteModal
        isOpen={fileToRestore !== null}
        title={lang === 'gu' ? 'ડેટાબેઝ રિસ્ટોર કન્ફર્મ કરો' : 'Confirm Database Restore'}
        message={
          lang === 'gu'
            ? `શું તમે ખરેખર "${fileToRestore?.name}" ફાઇલમાંથી ડેટા રિસ્ટોર કરવા માંગો છો? આનાથી વર્તમાન લોકલ ડેટા આ બેકઅપ મુજબ અપડેટ થશે.`
            : `Are you sure you want to restore data from "${fileToRestore?.name}"? Your local records will be updated with this snapshot.`
        }
        confirmButtonText={isRestoring ? (lang === 'gu' ? 'રિસ્ટોર થઈ રહ્યું છે...' : 'Restoring...') : (lang === 'gu' ? 'હા, રિસ્ટોર કરો' : 'Yes, Restore Data')}
        cancelButtonText={lang === 'gu' ? 'રદ કરો' : 'Cancel'}
        onConfirm={confirmRestore}
        onClose={() => setFileToRestore(null)}
        lang={lang}
      />
    </div>
  );
};
