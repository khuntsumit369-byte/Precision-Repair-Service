import React, { useState, useEffect } from 'react';
import {
  Cloud,
  CheckCircle2,
  RefreshCw,
  Smartphone,
  Laptop,
  Globe,
  Share2,
  X,
  ExternalLink,
  ShieldCheck,
  LogIn,
  LogOut,
  User as UserIcon,
} from 'lucide-react';
import { auth, googleProvider, signInWithPopup, signOut, onAuthStateChanged, User } from '../firebase';
import { SyncStatus } from '../utils/firestoreSync';

interface CloudSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'gu' | 'en';
  syncStatus: SyncStatus;
}

export const CloudSyncModal: React.FC<CloudSyncModalProps> = ({
  isOpen,
  onClose,
  lang,
  syncStatus,
}) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });
    return () => unsub();
  }, []);

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    try {
      setIsSigningIn(true);
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.warn('Google sign-in popup closed or cancelled:', err);
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden transform transition-all">
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-xs">
              <Cloud className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                {lang === 'gu' ? 'મલ્ટી-ડિવાઇસ ક્લાઉડ સિંક & વર્સેલ' : 'Multi-Device Cloud Sync & Vercel'}
              </h3>
              <p className="text-xs text-indigo-100">
                {lang === 'gu'
                  ? 'તમામ મોબાઇલ અને કમ્પ્યુટર પર રીઅલ-ટાઇમ લાઇવ ડેટા'
                  : 'Real-time live synchronization across all devices'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Status Badge */}
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <span className="flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
              </div>
              <div>
                <div className="text-sm font-bold text-emerald-950 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>
                    {lang === 'gu'
                      ? 'ક્લાઉડ ફાયરસ્ટોર ડેટાબેઝ સક્રિય છે'
                      : 'Cloud Firestore Database Active'}
                  </span>
                </div>
                <div className="text-xs text-emerald-700">
                  {lang === 'gu'
                    ? 'તમારા તમામ ઇન્વૉઇસ અને સ્ટોક આપોઆપ રીઅલ-ટાઇમ સિંક થાય છે.'
                    : 'All invoices, stock & payments sync instantly across connected devices.'}
                </div>
              </div>
            </div>
            {syncStatus.lastSyncedAt && (
              <div className="text-[11px] text-emerald-600 font-mono hidden sm:block">
                {syncStatus.lastSyncedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </div>
            )}
          </div>

          {/* User Account / Google Login (Optional) */}
          <div className="p-4 border border-slate-200 rounded-xl bg-slate-50 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-bold text-slate-800">
                  {lang === 'gu' ? 'ઓથેન્ટિકેશન એકાઉન્ટ' : 'Cloud Account & Identity'}
                </span>
              </div>
              {currentUser && (
                <span className="text-[11px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-medium">
                  {currentUser.email}
                </span>
              )}
            </div>

            {currentUser ? (
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2 text-xs text-slate-600">
                  {currentUser.photoURL ? (
                    <img src={currentUser.photoURL} alt="User" className="w-6 h-6 rounded-full" />
                  ) : (
                    <UserIcon className="w-5 h-5 text-slate-400" />
                  )}
                  <span>{currentUser.displayName || currentUser.email}</span>
                </div>
                <button
                  onClick={handleSignOut}
                  className="inline-flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 font-semibold px-2.5 py-1 rounded-lg hover:bg-rose-50 border border-rose-200"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{lang === 'gu' ? 'લોગ આઉટ' : 'Sign Out'}</span>
                </button>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                <p className="text-xs text-slate-500">
                  {lang === 'gu'
                    ? 'તમારા ગુગલ એકાઉન્ટથી સાઇન ઇન કરી વર્કશોપ ડેટા સુરક્ષિત રાખો:'
                    : 'Sign in with Google to manage and secure your workshop records:'}
                </p>
                <button
                  onClick={handleGoogleSignIn}
                  disabled={isSigningIn}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg shadow-2xs transition-colors shrink-0"
                >
                  <LogIn className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{isSigningIn ? 'સાઇન ઇન...' : 'Sign in with Google'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Multi-Device Guide */}
          <div className="border border-slate-200 rounded-xl p-4 space-y-3">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-blue-600" />
              <span>{lang === 'gu' ? 'મોબાઇલ & કોમ્પ્યુટર પર કેવી રીતે વાપરવું' : 'Using on Multiple Phones & Laptops'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
              <div className="p-3 bg-slate-50 rounded-lg space-y-1 border border-slate-100">
                <div className="font-bold text-slate-800 flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{lang === 'gu' ? '1. મોબાઇલ / ટેબ્લેટ' : '1. On Mobile / Tablet'}</span>
                </div>
                <p>
                  {lang === 'gu'
                    ? 'તમારા ફોનના ક્રોમ બ્રાઉઝરમાં એપ્લિકેશન લિંક ખોલો. તમે કાઉન્ટર પરથી લાઇવ બિલ બનાવી શકશો.'
                    : 'Open the app link in Chrome/Safari on your phone to create bills anywhere on the floor.'}
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg space-y-1 border border-slate-100">
                <div className="font-bold text-slate-800 flex items-center gap-1.5">
                  <Laptop className="w-3.5 h-3.5 text-blue-600" />
                  <span>{lang === 'gu' ? '2. ઓફિસ PC / લેપટોપ' : '2. On Office PC / Laptop'}</span>
                </div>
                <p>
                  {lang === 'gu'
                    ? 'ઓફિસ કમ્પ્યુટરમાં પણ તે જ લિંક ખોલો. મોબાઇલ પર બનાવેલ બિલ તરત જ સ્ક્રીન પર દેખાશે.'
                    : 'Open the same link on your desktop. Any entry saved on mobile reflects immediately on PC!'}
                </p>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between gap-2">
              <span className="text-xs text-slate-500 truncate">{window.location.origin}</span>
              <button
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg shrink-0 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>{copiedLink ? (lang === 'gu' ? 'લિંક કોપી થઈ ગઈ!' : 'Copied!') : (lang === 'gu' ? 'લિંક કોપી કરો' : 'Copy App Link')}</span>
              </button>
            </div>
          </div>

          {/* Vercel Deployment Instructions */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-900 text-slate-100 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between font-sans">
              <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-emerald-400">
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
                <span>{lang === 'gu' ? 'વર્સેલ (Vercel) પર ડિપ્લોય કરવાની રીત' : 'Deploying to Vercel'}</span>
              </div>
              <span className="text-[11px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                vercel.json ready
              </span>
            </div>

            <div className="text-slate-300 space-y-1.5 pl-2 border-l-2 border-indigo-500 font-sans text-xs">
              <p className="font-semibold text-white">
                {lang === 'gu' ? 'પગલું ૧: સોર્સ કોડ ઝીપ ડાઉનલોડ કરો અથવા GitHub પર પુશ કરો' : 'Step 1: Download the .ZIP code or push to your GitHub repo'}
              </p>
              <p className="font-semibold text-white">
                {lang === 'gu' ? 'પગલું ૨: Vercel.com પર જઈને "Add New Project" ક્લિક કરો' : 'Step 2: On Vercel.com, click "Add New Project" and import repo'}
              </p>
              <div className="bg-slate-950 p-2.5 rounded-lg text-slate-400 font-mono text-[11px] space-y-1">
                <p><span className="text-slate-500">Framework Preset:</span> <span className="text-emerald-400">Vite</span></p>
                <p><span className="text-slate-500">Build Command:</span> <span className="text-emerald-400">npm run build</span></p>
                <p><span className="text-slate-500">Output Directory:</span> <span className="text-emerald-400">dist</span></p>
              </div>
              <p className="text-slate-400">
                {lang === 'gu'
                  ? 'પગલું ૩: "Deploy" પર ક્લિક કરો. તમારી પોતાની ફ્રી .vercel.app ડોમેઈન પર ક્લાઉડ સિંક આપોઆપ ચાલશે!'
                  : 'Step 3: Click "Deploy". Your custom .vercel.app domain will sync live with Firebase Cloud Firestore!'}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
          >
            {lang === 'gu' ? 'સમજાયું, બંધ કરો' : 'Got it, Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
