import React from 'react';
import { Download, CheckCircle, Terminal, FolderArchive, X, ExternalLink } from 'lucide-react';

interface DownloadZipModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'gu' | 'en';
}

export const DownloadZipModal: React.FC<DownloadZipModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  if (!isOpen) return null;

  const handleDownloadAgain = () => {
    const link = document.createElement('a');
    link.href = '/repairflow-project.zip';
    link.download = 'repairflow-billing-app.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden transform transition-all">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-xs">
              <FolderArchive className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                {lang === 'gu' ? 'પ્રોજેક્ટ સોર્સ કોડ ડાઉનલોડ (.ZIP)' : 'Download Project Source (.ZIP)'}
              </h3>
              <p className="text-xs text-emerald-100">
                {lang === 'gu' ? 'સંપૂર્ણ રીએક્ટ & ટાઇપસ્ક્રિપ્ટ કોડબેઝ' : 'Complete React + TypeScript Project'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          <div className="flex items-center gap-3 p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900">
            <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
            <div className="text-xs sm:text-sm font-medium">
              {lang === 'gu'
                ? 'ડાઉનલોડ શરૂ થઈ ગયું છે! જો ડાઉનલોડ ન થયું હોય, તો નીચેના બટન પર ક્લિક કરો.'
                : 'Download has started! If it did not start automatically, click the button below.'}
            </div>
          </div>

          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500 font-semibold border-b border-slate-200 pb-2">
              <span className="flex items-center gap-1.5 text-slate-700">
                <FolderArchive className="w-4 h-4 text-emerald-600" />
                repairflow-billing-app.zip
              </span>
              <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full text-[11px]">
                ~4.9 MB
              </span>
            </div>

            <div className="text-xs text-slate-600 space-y-1">
              <p className="font-bold text-slate-800">
                {lang === 'gu' ? 'ઝીપ ફાઇલ માં સામેલ છે:' : 'Included in ZIP Archive:'}
              </p>
              <ul className="list-disc list-inside space-y-0.5 text-slate-600 pl-1">
                <li><code>src/</code> (Components, Types, Utils, Data)</li>
                <li><code>public/</code> (Logos, Icons, Assets)</li>
                <li><code>package.json</code> &amp; <code>tsconfig.json</code></li>
                <li><code>vite.config.ts</code> &amp; <code>index.html</code></li>
                <li><code>README.md</code> (Setup &amp; Run instructions)</li>
              </ul>
            </div>
          </div>

          {/* Quick Terminal Guide */}
          <div className="bg-slate-900 text-slate-100 rounded-xl p-4 space-y-2 text-xs font-mono">
            <div className="flex items-center gap-2 text-slate-400 font-sans font-bold text-xs uppercase tracking-wider">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'gu' ? 'લોકલ કમ્પ્યુટર પર કેવી રીતે ચલાવવું' : 'How to Run Locally'}</span>
            </div>
            <div className="text-slate-300 space-y-1 pl-2 border-l-2 border-emerald-500">
              <p className="text-slate-400"># 1. Extract ZIP &amp; open folder in terminal</p>
              <p className="text-emerald-400">npm install</p>
              <p className="text-slate-400"># 2. Run local development server</p>
              <p className="text-emerald-400">npm run dev</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <a
              href="/repairflow-project.zip"
              download="repairflow-billing-app.zip"
              onClick={handleDownloadAgain}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs sm:text-sm shadow-md transition-all hover:scale-[1.02]"
            >
              <Download className="w-4 h-4" />
              <span>{lang === 'gu' ? 'ફરીથી ડાઉનલોડ કરો (.ZIP)' : 'Download Again (.ZIP)'}</span>
            </a>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
            >
              {lang === 'gu' ? 'બંધ કરો' : 'Close'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
