import React, { useState } from 'react';
import { WorkshopSettings } from '../types';
import {
  Settings,
  Save,
  RotateCcw,
  Building,
  Phone,
  MapPin,
  Shield,
  Check,
  Image as ImageIcon,
  Upload,
  Download,
  FolderArchive,
  Terminal,
  HardDrive,
  ExternalLink,
  Cloud,
  Database,
  FileJson,
  Smartphone,
  Laptop,
  RefreshCw,
} from 'lucide-react';
import { resetAllToDefault } from '../utils/storage';
import { ConfirmDeleteModal } from './ConfirmDeleteModal';
import { DownloadZipModal } from './DownloadZipModal';
import { GoogleDriveBackupModal } from './GoogleDriveBackupModal';
import { CloudSyncModal } from './CloudSyncModal';
import { DEFAULT_DRIVE_FOLDER_URL } from '../utils/googleDriveBackup';
import { SyncStatus } from '../utils/firestoreSync';

interface WorkshopSettingsViewProps {
  settings: WorkshopSettings;
  onSaveSettings: (settings: WorkshopSettings) => void;
  onResetData: () => void;
  lang: 'gu' | 'en';
  currentData?: any;
  onRestoreData?: (restoredData: any) => void;
  syncStatus?: SyncStatus;
}

export const WorkshopSettingsView: React.FC<WorkshopSettingsViewProps> = ({
  settings,
  onSaveSettings,
  onResetData,
  lang,
  currentData,
  onRestoreData,
  syncStatus = { isOnline: true, isSyncing: false, lastSyncedAt: null, error: null },
}) => {
  const [formData, setFormData] = useState<WorkshopSettings>({ ...settings });
  const [savedMessage, setSavedMessage] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [showDriveModal, setShowDriveModal] = useState(false);
  const [showCloudSyncModal, setShowCloudSyncModal] = useState(false);

  const handleDownloadZip = () => {
    const link = document.createElement('a');
    link.href = '/repairflow-project.zip';
    link.download = 'repairflow-billing-app.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setShowDownloadModal(true);
  };

  const handleExportJson = () => {
    try {
      const dataToExport = currentData || {
        settings: formData,
      };
      const jsonStr = JSON.stringify(dataToExport, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = new Date().toISOString().split('T')[0];
      a.href = url;
      a.download = `repairflow_complete_backup_${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Export JSON error', e);
    }
  };

  const handleImportJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onRestoreData) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          onRestoreData(parsed);
          setSavedMessage(true);
          setTimeout(() => setSavedMessage(false), 3000);
        } catch (err) {
          console.error('Restore error', err);
          alert(lang === 'gu' ? 'અમાન્ય બેકઅપ JSON ફાઇલ' : 'Invalid backup JSON file');
        }
      };
      reader.readAsText(file);
    }
  };

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setFormData({ ...formData, logoUrl: event.target.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 2500);
  };

  const handleConfirmReset = () => {
    resetAllToDefault();
    onResetData();
    setShowResetConfirm(false);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-600" />
            <span>
              {lang === 'gu' ? 'દુકાન અને બિલ સેટિંગ્સ' : 'Workshop & Invoice Settings'}
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {lang === 'gu'
              ? 'દુકાનનું નામ, ફોન નંબર, સરનામું અને બિલની શરતો સેટ કરો'
              : 'Customize workshop brand, contact details, warranty terms, and address on printed bills.'}
          </p>
        </div>

        {savedMessage && (
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-semibold animate-in fade-in">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>{lang === 'gu' ? 'સેટિંગ્સ સાચવ્યા!' : 'Settings Saved!'}</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        {/* Business details */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 border-b border-slate-100 pb-2 flex items-center gap-2">
            <Building className="w-4 h-4 text-indigo-600" />
            <span>{lang === 'gu' ? 'દુકાન / વર્કશોપ વિગત' : 'Workshop Information'}</span>
          </h2>

          {/* Logo Upload & Preview */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
            <label className="block text-xs font-semibold text-slate-800 mb-2 flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-indigo-600" />
              <span>{lang === 'gu' ? 'દુકાનનો ઓફિશિયલ લોગો (Workshop Logo)' : 'Official Workshop Logo'}</span>
            </label>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="w-20 h-20 rounded-xl bg-white border-2 border-indigo-200 p-1 flex items-center justify-center shadow-xs overflow-hidden shrink-0">
                <img
                  src={formData.logoUrl || '/1788617143683.png'}
                  alt="Logo Preview"
                  className="w-full h-full object-contain rounded-lg"
                />
              </div>
              <div className="flex-1 w-full space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{lang === 'gu' ? 'કમ્પ્યુટરમાંથી નવો લોગો અપલોડ કરો' : 'Upload New Logo Image'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoFileChange}
                      className="hidden"
                    />
                  </label>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, logoUrl: '/1788617143683.png' })}
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-medium transition-colors"
                  >
                    {lang === 'gu' ? 'ડિફોલ્ટ લોગો રાખો' : 'Reset to Default Logo'}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  {lang === 'gu'
                    ? 'આ લોગો સોફ્ટવેરમાં ઉપર હેડરમાં, બિલના A5 અને A4 પ્રિન્ટમાં, વોટરમાર્કમાં તથા સ્ટીકર્સમાં દેખાશે.'
                    : 'This logo appears in header, on A5 & A4 print invoices, background watermark, and unit tracking stickers.'}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'gu' ? 'દુકાનનું નામ (Workshop Name English)' : 'Workshop Name (English)'} *
              </label>
              <input
                type="text"
                required
                value={formData.workshopName}
                onChange={(e) => setFormData({ ...formData, workshopName: e.target.value })}
                className="w-full px-3 py-2 text-sm font-bold text-slate-900 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'gu' ? 'દુકાનનું નામ (ગુજરાતીમાં)' : 'Workshop Name (Gujarati)'}
              </label>
              <input
                type="text"
                value={formData.workshopNameGu}
                onChange={(e) => setFormData({ ...formData, workshopNameGu: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'gu' ? 'ટેગલાઇન / વિગત' : 'Tagline / Specialty'}
              </label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'gu' ? 'માલિક / ટેકનિશિયનનું નામ' : 'Owner / Head Technician'}
              </label>
              <input
                type="text"
                value={formData.ownerName}
                onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                GSTIN / Tax ID
              </label>
              <input
                type="text"
                value={formData.gstin || ''}
                onChange={(e) => setFormData({ ...formData, gstin: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-xl"
                placeholder="24AAAAA0000A1Z5"
              />
            </div>
          </div>
        </div>

        {/* Contact and address */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 border-b border-slate-100 pb-2 flex items-center gap-2">
            <Phone className="w-4 h-4 text-indigo-600" />
            <span>{lang === 'gu' ? 'સંપર્ક અને સરનામું' : 'Contact & Address'}</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'gu' ? 'મોબાઇલ નંબર' : 'Primary Phone'} *
              </label>
              <input
                type="text"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'gu' ? 'બીજો મોબાઇલ નંબર (Alternative)' : 'Alternate Phone'}
              </label>
              <input
                type="text"
                value={formData.altPhone || ''}
                onChange={(e) => setFormData({ ...formData, altPhone: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'gu' ? 'સરનામું (Address)' : 'Shop Address'}
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'gu' ? 'શહેર અને પીનકોડ' : 'City & Pincode'}
              </label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl"
              />
            </div>
          </div>
        </div>

        {/* Warranty and Terms */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 border-b border-slate-100 pb-2 flex items-center gap-2">
            <Shield className="w-4 h-4 text-indigo-600" />
            <span>{lang === 'gu' ? 'વોરંટી અને શરતો' : 'Default Warranty & Terms'}</span>
          </h2>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {lang === 'gu' ? 'ડિફોલ્ટ વોરંટી (દિવસો)' : 'Default Warranty (Days)'}
            </label>
            <input
              type="number"
              min="0"
              value={formData.defaultWarrantyDays}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  defaultWarrantyDays: parseInt(e.target.value) || 0,
                })
              }
              className="w-32 px-3 py-2 text-sm font-mono border border-slate-300 rounded-xl"
            />
          </div>
        </div>

        <div className="pt-4 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200">
          <button
            type="button"
            onClick={() => setShowResetConfirm(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-xl transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{lang === 'gu' ? 'ડેમો ડેટા રીસેટ કરો' : 'Reset Demo Data'}</span>
          </button>

          <button
            type="submit"
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-xl shadow-sm transition-all"
          >
            <Save className="w-4 h-4" />
            <span>{lang === 'gu' ? 'સેટિંગ્સ સેવ કરો' : 'Save Settings'}</span>
          </button>
        </div>
      </form>

      {/* BACKUP, CLOUD SYNC & CODE EXPORT HUB */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 px-1">
          <Database className="w-5 h-5 text-indigo-600" />
          <h2 className="text-base font-bold text-slate-900">
            {lang === 'gu'
              ? 'ક્લાઉડ સિંક, ડ્રાઇવ બેકઅપ અને સોર્સ કોડ'
              : 'Cloud Sync, Google Drive Backup & Source Code'}
          </h2>
        </div>

        {/* 1. Google Drive Cloud Backup & Folder Sync Card (Amber) */}
        <div className="bg-white p-6 rounded-2xl border-2 border-amber-200 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-100 text-amber-700 rounded-xl">
                <HardDrive className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-slate-900">
                    {lang === 'gu' ? 'ગુગલ ડ્રાઇવ ક્લાઉડ બેકઅપ & ફોલ્ડર સિંક' : 'Google Drive Cloud Backup & Folder Sync'}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                    Connected Drive
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  {lang === 'gu'
                    ? 'તમારા પર્સનલ ગૂગલ ડ્રાઇવ ફોલ્ડરમાં ડેટાબેઝ સ્નેપશોટ અને સોર્સ કોડ સેવ કરો'
                    : 'Save full database snapshots & project code directly into your designated Google Drive folder.'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <a
                href={DEFAULT_DRIVE_FOLDER_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              >
                <span>{lang === 'gu' ? 'ડ્રાઇવ ફોલ્ડર ખોલો' : 'Open Folder'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                type="button"
                onClick={() => setShowDriveModal(true)}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-all hover:scale-[1.02]"
              >
                <HardDrive className="w-4 h-4" />
                <span>{lang === 'gu' ? 'Google Drive બેકઅપ & રીસ્ટોર' : 'Google Drive Backup & Restore'}</span>
              </button>
            </div>
          </div>

          <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="truncate">
              <span className="font-bold">{lang === 'gu' ? 'કનેક્ટેડ ફોલ્ડર:' : 'Connected Folder:'} </span>
              <span className="font-mono text-[11px] text-amber-800 select-all">{DEFAULT_DRIVE_FOLDER_URL}</span>
            </div>
            <span className="text-[11px] font-semibold text-amber-700 shrink-0">
              {lang === 'gu' ? 'ઓટો સેવ અને ક્લાઉડ સ્ટોરેજ તૈયાર' : 'Ready for Cloud Snapshots'}
            </span>
          </div>
        </div>

        {/* 2. Multi-Device Real-Time Cloud Sync (Firebase Firestore) Card (Indigo) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
                <Cloud className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-slate-900">
                    {lang === 'gu' ? 'મલ્ટી-ડિવાઇસ રીયલ-ટાઇમ ક્લાઉડ સિંક' : 'Multi-Device Real-Time Cloud Sync'}
                  </h3>
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                    </span>
                    {syncStatus.isSyncing
                      ? (lang === 'gu' ? 'સિંક થઈ રહ્યું છે...' : 'Syncing...')
                      : (lang === 'gu' ? 'લાઇવ કનેક્ટેડ' : 'Live Connected')}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  {lang === 'gu'
                    ? 'દુકાનના મોબાઈલ, લેપટોપ અને ઓફિસ પીસી વચ્ચે ડેટા ઓટોમેટિક લાઈવ સિંક થાય છે'
                    : 'Real-time synchronization across workshop smartphones, laptops, and counter PCs.'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowCloudSyncModal(true)}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-all hover:scale-[1.02]"
            >
              <Cloud className="w-4 h-4" />
              <span>{lang === 'gu' ? 'ક્લાઉડ સિંક વિગતો & લૉગિન' : 'Cloud Sync Details & Auth'}</span>
            </button>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-slate-500" />
              <span className="text-slate-600">{lang === 'gu' ? 'મોબાઇલ ફોન સિંક' : 'Mobile Phone Access'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Laptop className="w-4 h-4 text-slate-500" />
              <span className="text-slate-600">{lang === 'gu' ? 'લેપટોપ / પીસી સિંક' : 'Desktop Counter Sync'}</span>
            </div>
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-emerald-600" />
              <span className="text-slate-600">
                {syncStatus.lastSyncedAt
                  ? `${lang === 'gu' ? 'છેલ્લો સિંક:' : 'Last Synced:'} ${syncStatus.lastSyncedAt.toLocaleTimeString()}`
                  : (lang === 'gu' ? 'રીયલ-ટાઇમ ક્લાઉડ સક્રિય' : 'Real-time sync active')}
              </span>
            </div>
          </div>
        </div>

        {/* 3. Project Source Code Download & Backup Section (Emerald) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-xl">
                <FolderArchive className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {lang === 'gu' ? 'પ્રોજેક્ટ સોર્સ કોડ ડાઉનલોડ (.ZIP)' : 'Download Full Project Source Code (.ZIP)'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {lang === 'gu'
                    ? 'આ સંપૂર્ણ એપ્લિકેશનનો કોડ ઝીપ ફાઇલ તરીકે ડાઉનલોડ કરો અને તમારા પોતાના કોમ્પ્યુટર કે સર્વર પર ચલાવો'
                    : 'Download the complete application code as a ZIP archive (~4.9 MB) to run offline or host on Vercel.'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleDownloadZip}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-all hover:scale-[1.02]"
            >
              <Download className="w-4 h-4" />
              <span>{lang === 'gu' ? '.ZIP ફાઇલ ડાઉનલોડ કરો' : 'Download .ZIP File'}</span>
            </button>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <Terminal className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'gu' ? 'કમ્પ્યુટર પર કેવી રીતે ઇન્સ્ટોલ કરવું:' : 'Quick Local Setup Guide:'}</span>
            </div>
            <div className="font-mono bg-slate-900 text-slate-100 p-3 rounded-lg text-xs space-y-1">
              <p className="text-slate-400"># 1. Extract zip and navigate to project</p>
              <p className="text-emerald-400">npm install</p>
              <p className="text-slate-400"># 2. Start local development server</p>
              <p className="text-emerald-400">npm run dev</p>
              <p className="text-slate-400"># 3. Deploy directly to Vercel (optional)</p>
              <p className="text-cyan-400">npx vercel --prod</p>
            </div>
          </div>
        </div>

        {/* 4. Local JSON File Backup & Restore Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-slate-100 text-slate-700 rounded-xl">
                <FileJson className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {lang === 'gu' ? 'ઓફલાઇન JSON ડેટા બેકઅપ અને રીસ્ટોર' : 'Offline JSON Data Backup & Restore'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {lang === 'gu'
                    ? 'બધા ગ્રાહકો, ઇન્વોઇસ, સ્ટોક અને ચુકવણીઓનો ઓફલાઇન બેકઅપ સેવ કરો અથવા અગાઉનો બેકઅપ પાછો લાવો'
                    : 'Download an immediate full JSON snapshot of all records, or import a previously downloaded backup.'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleExportJson}
                className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>{lang === 'gu' ? 'JSON બેકઅપ ડાઉનલોડ' : 'Download JSON Backup'}</span>
              </button>

              <label className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs sm:text-sm font-semibold shadow-xs transition-colors">
                <Upload className="w-4 h-4 text-slate-600" />
                <span>{lang === 'gu' ? 'JSON ફાઇલમાંથી રીસ્ટોર' : 'Restore from JSON'}</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleImportJsonFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* REUSABLE CUSTOM IN-UI RESET CONFIRMATION MODAL */}
      <ConfirmDeleteModal
        isOpen={showResetConfirm}
        title={lang === 'gu' ? 'ડેમો ડેટા રીસેટ કરો' : 'Reset Demo Data'}
        message={
          lang === 'gu'
            ? 'શું તમે બધો ડેટા રીસેટ કરીને ફરીથી ડિફોલ્ટ ઇનવોઇસ અને સ્પેરપાર્ટ્સ લોડ કરવા માંગો છો?'
            : 'Reset all application data back to default state?'
        }
        confirmButtonText={lang === 'gu' ? 'હા, રીસેટ કરો' : 'Yes, Reset Data'}
        cancelButtonText={lang === 'gu' ? 'રદ કરો' : 'Cancel'}
        onConfirm={handleConfirmReset}
        onClose={() => setShowResetConfirm(false)}
        lang={lang}
      />

      {/* DOWNLOAD ZIP MODAL */}
      <DownloadZipModal
        isOpen={showDownloadModal}
        onClose={() => setShowDownloadModal(false)}
        lang={lang}
      />

      {/* GOOGLE DRIVE BACKUP MODAL */}
      <GoogleDriveBackupModal
        isOpen={showDriveModal}
        onClose={() => setShowDriveModal(false)}
        lang={lang}
        currentData={currentData || {}}
        onRestoreData={onRestoreData || (() => {})}
      />

      {/* CLOUD SYNC MODAL */}
      <CloudSyncModal
        isOpen={showCloudSyncModal}
        onClose={() => setShowCloudSyncModal(false)}
        lang={lang}
        syncStatus={syncStatus}
      />
    </div>
  );
};
