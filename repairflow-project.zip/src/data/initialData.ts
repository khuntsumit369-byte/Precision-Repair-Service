import { CatalogItem, Customer, ExpenseRecord, Invoice, PaymentRecord, PurchaseRecord, WorkshopSettings, UnitMasterItem, SupplierClient, StaffMember } from '../types';

export const INITIAL_SETTINGS: WorkshopSettings = {
  workshopName: 'PRECISION REPAIR SERVICE',
  workshopNameGu: 'પ્રિસિઝન રિપેર સર્વિસ (PRECISION REPAIR SERVICE)',
  tagline: 'Micromotors, Controllers & Dental Handpiece Repair Specialists',
  ownerName: 'Sumit Patel',
  phone: '+91 98765 43210',
  altPhone: '+91 98250 12345',
  email: 'service@precisionrepair.com',
  address: 'Shop No. 12, Soni Bazar, Gold Complex, Near Tower',
  city: 'Rajkot - 360001, Gujarat',
  gstin: '24AAAAA0000A1Z5',
  logoUrl: '/1788617143683.png',
  terms: [
    'Unit tracking code sticker is affixed on each machine for service identification.',
    'Please inspect and verify the machine working at the time of delivery.',
    'Payment due on presentation of invoice.'
  ],
  defaultWarrantyDays: 0,
  currencySymbol: '₹',
};

export const INITIAL_CATALOG: CatalogItem[] = [
  {
    id: 'item-brg-01',
    code: 'PRT-BRG-70',
    name: 'Bearing',
    nameGu: 'બેરિંગ',
    type: 'part',
    salePrice: 70,
    costPrice: 42,
    stock: 85,
    unit: 'pcs',
    category: 'Mechanical Spare Parts'
  },
  {
    id: 'item-msf-01',
    code: 'PRT-MSF-80',
    name: 'MOSFET',
    nameGu: 'મોસ્ફેટ (ટ્રાન્ઝિસ્ટર)',
    type: 'part',
    salePrice: 80,
    costPrice: 48,
    stock: 50,
    unit: 'pcs',
    category: 'Electronic Components'
  },
  {
    id: 'item-cbl-01',
    code: 'PRT-CBL-250',
    name: 'Cable',
    nameGu: 'કેબલ / વાયર કોર્ડ',
    type: 'part',
    salePrice: 250,
    costPrice: 155,
    stock: 28,
    unit: 'pcs',
    category: 'Cables & Wires'
  },
  {
    id: 'item-cpl-01',
    code: 'PRT-CPL-40',
    name: 'Coupler',
    nameGu: 'કપ્લર',
    type: 'part',
    salePrice: 40,
    costPrice: 22,
    stock: 65,
    unit: 'pcs',
    category: 'Mechanical Spare Parts'
  },
  {
    id: 'item-sw-01',
    code: 'PRT-SW-30',
    name: 'Switch',
    nameGu: 'સ્વીચ',
    type: 'part',
    salePrice: 30,
    costPrice: 16,
    stock: 90,
    unit: 'pcs',
    category: 'Electrical Components'
  },
  {
    id: 'item-srv-hp',
    code: 'SRV-HP-200',
    name: 'Handpiece Service Charge',
    nameGu: 'હેન્ડપીસ સર્વિસ ચાર્જ',
    type: 'service',
    salePrice: 200,
    costPrice: 0,
    unit: 'job',
    category: 'Labor & Servicing'
  },
  {
    id: 'item-srv-mot',
    code: 'SRV-MOT-150',
    name: 'Motor Service Charge',
    nameGu: 'મોટર સર્વિસ ચાર્જ',
    type: 'service',
    salePrice: 150,
    costPrice: 0,
    unit: 'job',
    category: 'Labor & Servicing'
  },
  {
    id: 'item-cb-01',
    code: 'PRT-CB-90',
    name: 'Carbon Brush Set',
    nameGu: 'કાર્બન બ્રશ સેટ',
    type: 'part',
    salePrice: 90,
    costPrice: 50,
    stock: 45,
    unit: 'set',
    category: 'Mechanical Spare Parts'
  },
  {
    id: 'item-pcb-srv',
    code: 'SRV-PCB-350',
    name: 'PCB / Control Board Repair',
    nameGu: 'કંટ્રોલ બોર્ડ / પીસીબી રીપેરિંગ',
    type: 'service',
    salePrice: 350,
    costPrice: 0,
    unit: 'job',
    category: 'Labor & Servicing'
  }
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-govindji',
    name: 'Govindji Jewellers',
    contactPerson: 'Shree Govindbhai',
    phone: '+91 98242 11223',
    city: 'Rajkot',
    address: 'Near Palace Road, Gold Market',
    gstNumber: '24AABCG1234F1Z8',
    balanceDue: 0,
    totalInvoicesCount: 1,
    totalBilledAmount: 2740
  },
  {
    id: 'cust-ambica',
    name: 'Ambica Ornaments',
    contactPerson: 'Hareshbhai',
    phone: '+91 99090 44556',
    city: 'Ahmedabad',
    address: 'Manek Chowk',
    balanceDue: 1450,
    totalInvoicesCount: 1,
    totalBilledAmount: 1450
  },
  {
    id: 'cust-shree-radhe',
    name: 'Radhe Jewellery Works',
    contactPerson: 'Pravinbhai',
    phone: '+91 97230 77889',
    city: 'Surat',
    address: 'Varachha Road',
    balanceDue: 0,
    totalInvoicesCount: 0,
    totalBilledAmount: 0
  }
];

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-2026-0801',
    invoiceNumber: 'INV-2026-0801',
    date: '2026-08-25',
    customerId: 'cust-govindji',
    customerName: 'Govindji Jewellers',
    customerPhone: '+91 98242 11223',
    customerCity: 'Rajkot',
    totalUnitsCount: 7,
    partsTotal: 1290,
    servicesTotal: 1250,
    subtotal: 2740,
    discount: 0,
    taxPercent: 0,
    taxAmount: 0,
    grandTotal: 2740,
    paidAmount: 2740,
    balanceDue: 0,
    paymentStatus: 'Paid',
    paymentMode: 'UPI',
    remarks: '4 Handpieces and 3 Motors fully serviced and tested. Unit performance codes tagged.',
    createdAt: '2026-08-25T14:30:00.000Z',
    units: [
      {
        id: 'unit-hp-1',
        unitType: 'Handpiece',
        unitName: 'Handpiece 1',
        trackingCode: 'HP-260825-01',
        brandModel: 'Marathon SDE-H37L1',
        reportedIssue: 'Noise and loose wire cord',
        technicianNotes: 'Replaced internal front bearing and power cable. Tested at 35,000 RPM smooth run.',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [
          {
            id: 'p-hp1-1',
            catalogItemId: 'item-cbl-01',
            name: 'Cable',
            code: 'PRT-CBL-250',
            quantity: 1,
            unitPrice: 250,
            totalPrice: 250
          },
          {
            id: 'p-hp1-2',
            catalogItemId: 'item-brg-01',
            name: 'Bearing',
            code: 'PRT-BRG-70',
            quantity: 1,
            unitPrice: 70,
            totalPrice: 70
          }
        ],
        services: [
          {
            id: 's-hp1-1',
            catalogItemId: 'item-srv-hp',
            name: 'Handpiece Service Charge',
            charge: 200
          }
        ],
        unitSubtotal: 520
      },
      {
        id: 'unit-hp-2',
        unitType: 'Handpiece',
        unitName: 'Handpiece 2',
        trackingCode: 'HP-260825-02',
        brandModel: 'Strong 102L',
        reportedIssue: 'High friction & heating up',
        technicianNotes: 'Rear bearing replaced. Cleaned and lubricated.',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [
          {
            id: 'p-hp2-1',
            catalogItemId: 'item-brg-01',
            name: 'Bearing',
            code: 'PRT-BRG-70',
            quantity: 1,
            unitPrice: 70,
            totalPrice: 70
          }
        ],
        services: [
          {
            id: 's-hp2-1',
            catalogItemId: 'item-srv-hp',
            name: 'Handpiece Service Charge',
            charge: 200
          }
        ],
        unitSubtotal: 270
      },
      {
        id: 'unit-hp-3',
        unitType: 'Handpiece',
        unitName: 'Handpiece 3',
        trackingCode: 'HP-260825-03',
        brandModel: 'NSK Style Chuck',
        reportedIssue: 'Chuck wobbling, 2 bearings damaged',
        technicianNotes: 'Coupler & double bearings installed. Concentricity verified.',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [
          {
            id: 'p-hp3-1',
            catalogItemId: 'item-cpl-01',
            name: 'Coupler',
            code: 'PRT-CPL-40',
            quantity: 1,
            unitPrice: 40,
            totalPrice: 40
          },
          {
            id: 'p-hp3-2',
            catalogItemId: 'item-brg-01',
            name: 'Bearing',
            code: 'PRT-BRG-70',
            quantity: 2,
            unitPrice: 70,
            totalPrice: 140
          }
        ],
        services: [
          {
            id: 's-hp3-1',
            catalogItemId: 'item-srv-hp',
            name: 'Handpiece Service Charge',
            charge: 200
          }
        ],
        unitSubtotal: 380
      },
      {
        id: 'unit-hp-4',
        unitType: 'Handpiece',
        unitName: 'Handpiece 4',
        trackingCode: 'HP-260825-04',
        brandModel: 'Champion Silver',
        reportedIssue: 'General cleaning and checkup',
        technicianNotes: 'Complete ultrasonic de-greasing, carbon cleaning, and oiling done.',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [],
        services: [
          {
            id: 's-hp4-1',
            catalogItemId: 'item-srv-hp',
            name: 'Handpiece Service Charge',
            charge: 200
          }
        ],
        unitSubtotal: 200
      },
      {
        id: 'unit-mot-1',
        unitType: 'Motor',
        unitName: 'Motor 1',
        trackingCode: 'MOT-260825-01',
        brandModel: 'Marathon Escort Control Box',
        reportedIssue: 'Dead unit, power fluctuation damaged MOSFET',
        technicianNotes: 'Power MOSFET replaced, input cable replaced, rocker power switch changed.',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [
          {
            id: 'p-mot1-1',
            catalogItemId: 'item-cbl-01',
            name: 'Cable',
            code: 'PRT-CBL-250',
            quantity: 1,
            unitPrice: 250,
            totalPrice: 250
          },
          {
            id: 'p-mot1-2',
            catalogItemId: 'item-msf-01',
            name: 'MOSFET',
            code: 'PRT-MSF-80',
            quantity: 1,
            unitPrice: 80,
            totalPrice: 80
          },
          {
            id: 'p-mot1-3',
            catalogItemId: 'item-sw-01',
            name: 'Switch',
            code: 'PRT-SW-30',
            quantity: 1,
            unitPrice: 30,
            totalPrice: 30
          }
        ],
        services: [
          {
            id: 's-mot1-1',
            catalogItemId: 'item-srv-mot',
            name: 'Motor Service Charge',
            charge: 150
          }
        ],
        unitSubtotal: 510
      },
      {
        id: 'unit-mot-2',
        unitType: 'Motor',
        unitName: 'Motor 2',
        trackingCode: 'MOT-260825-02',
        brandModel: 'Strong 204 Motor Unit',
        reportedIssue: 'Forward/Reverse switch loose',
        technicianNotes: 'Switch replaced and circuit contact serviced.',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [
          {
            id: 'p-mot2-1',
            catalogItemId: 'item-sw-01',
            name: 'Switch',
            code: 'PRT-SW-30',
            quantity: 1,
            unitPrice: 30,
            totalPrice: 30
          }
        ],
        services: [
          {
            id: 's-mot2-1',
            catalogItemId: 'item-srv-mot',
            name: 'Motor Service Charge',
            charge: 150
          }
        ],
        unitSubtotal: 180
      },
      {
        id: 'unit-mot-3',
        unitType: 'Motor',
        unitName: 'Motor 3',
        trackingCode: 'MOT-260825-03',
        brandModel: 'Kavo Style Micro Motor',
        reportedIssue: 'Overheating and cutting off under load',
        technicianNotes: 'Speed circuit MOSFET replaced, high-gauge motor cable replaced.',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [
          {
            id: 'p-mot3-1',
            catalogItemId: 'item-cbl-01',
            name: 'Cable',
            code: 'PRT-CBL-250',
            quantity: 1,
            unitPrice: 250,
            totalPrice: 250
          },
          {
            id: 'p-mot3-2',
            catalogItemId: 'item-msf-01',
            name: 'MOSFET',
            code: 'PRT-MSF-80',
            quantity: 1,
            unitPrice: 80,
            totalPrice: 80
          }
        ],
        services: [
          {
            id: 's-mot3-1',
            catalogItemId: 'item-srv-mot',
            name: 'Motor Service Charge',
            charge: 150
          }
        ],
        unitSubtotal: 480
      }
    ]
  },
  {
    id: 'inv-2026-0802',
    invoiceNumber: 'INV-2026-0802',
    date: '2026-08-26',
    customerId: 'cust-ambica',
    customerName: 'Ambica Ornaments',
    customerPhone: '+91 99090 44556',
    customerCity: 'Ahmedabad',
    totalUnitsCount: 2,
    partsTotal: 1050,
    servicesTotal: 400,
    subtotal: 1450,
    discount: 0,
    taxPercent: 0,
    taxAmount: 0,
    grandTotal: 1450,
    paidAmount: 0,
    balanceDue: 1450,
    paymentStatus: 'Unpaid',
    paymentMode: 'Cash',
    remarks: '2 Handpieces repaired. Pending payment.',
    createdAt: '2026-08-26T11:00:00.000Z',
    units: [
      {
        id: 'unit-amb-1',
        unitType: 'Handpiece',
        unitName: 'Handpiece 1',
        trackingCode: 'HP-260826-01',
        brandModel: 'Marathon SDE',
        reportedIssue: 'Cable tear and bearing noise',
        technicianNotes: 'Cable and 2 Bearings replaced',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [
          {
            id: 'p-amb1-1',
            catalogItemId: 'item-cbl-01',
            name: 'Cable',
            code: 'PRT-CBL-250',
            quantity: 1,
            unitPrice: 250,
            totalPrice: 250
          },
          {
            id: 'p-amb1-2',
            catalogItemId: 'item-brg-01',
            name: 'Bearing',
            code: 'PRT-BRG-70',
            quantity: 2,
            unitPrice: 70,
            totalPrice: 140
          }
        ],
        services: [
          {
            id: 's-amb1-1',
            catalogItemId: 'item-srv-hp',
            name: 'Handpiece Service Charge',
            charge: 200
          }
        ],
        unitSubtotal: 590
      },
      {
        id: 'unit-amb-2',
        unitType: 'Handpiece',
        unitName: 'Handpiece 2',
        trackingCode: 'HP-260826-02',
        brandModel: 'Strong 102L',
        reportedIssue: 'Cable cut and chuck loose',
        technicianNotes: 'Cable replaced and chuck overhaul',
        warrantyDays: 30,
        status: 'Repaired',
        parts: [
          {
            id: 'p-amb2-1',
            catalogItemId: 'item-cbl-01',
            name: 'Cable',
            code: 'PRT-CBL-250',
            quantity: 2,
            unitPrice: 250,
            totalPrice: 500
          },
          {
            id: 'p-amb2-2',
            catalogItemId: 'item-cpl-01',
            name: 'Coupler',
            code: 'PRT-CPL-40',
            quantity: 4,
            unitPrice: 40,
            totalPrice: 160
          }
        ],
        services: [
          {
            id: 's-amb2-1',
            catalogItemId: 'item-srv-hp',
            name: 'Handpiece Service Charge',
            charge: 200
          }
        ],
        unitSubtotal: 860
      }
    ]
  }
];

export const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: 'pay-2026-0801',
    invoiceId: 'inv-2026-0801',
    invoiceNumber: 'INV-2026-0801',
    customerId: 'cust-govindji',
    customerName: 'Govindji Jewellers',
    date: '2026-08-25',
    amount: 2740,
    paymentMode: 'UPI',
    referenceNo: 'UPI/260825/99881',
    notes: 'Full payment received via UPI on delivery',
    createdAt: '2026-08-25T15:00:00.000Z'
  }
];

export const INITIAL_PURCHASES: PurchaseRecord[] = [
  {
    id: 'pur-2026-0801',
    purchaseNo: 'PUR-2026-0801',
    billNumber: 'GST-9921',
    vendorName: 'Royal Spares & Tools, Rajkot',
    vendorPhone: '+91 98980 11223',
    date: '2026-08-20',
    totalAmount: 14850,
    paidAmount: 14850,
    paymentMode: 'Bank Transfer',
    notes: 'Bulk stock of Handpiece Bearings, Cables, MOSFETs and Couplers',
    createdAt: '2026-08-20T10:00:00.000Z',
    items: [
      {
        id: 'pi-1',
        catalogItemId: 'item-brg-01',
        name: 'Bearing',
        code: 'PRT-BRG-70',
        quantity: 100,
        unitCost: 42,
        totalCost: 4200
      },
      {
        id: 'pi-2',
        catalogItemId: 'item-cbl-01',
        name: 'Cable',
        code: 'PRT-CBL-250',
        quantity: 35,
        unitCost: 155,
        totalCost: 5425
      },
      {
        id: 'pi-3',
        catalogItemId: 'item-msf-01',
        name: 'MOSFET',
        code: 'PRT-MSF-80',
        quantity: 60,
        unitCost: 48,
        totalCost: 2880
      },
      {
        id: 'pi-4',
        catalogItemId: 'item-cpl-01',
        name: 'Coupler',
        code: 'PRT-CPL-40',
        quantity: 75,
        unitCost: 22,
        totalCost: 1650
      },
      {
        id: 'pi-5',
        catalogItemId: 'item-sw-01',
        name: 'Switch',
        code: 'PRT-SW-30',
        quantity: 100,
        unitCost: 16,
        totalCost: 1600
      }
    ]
  }
];

export const INITIAL_EXPENSES: ExpenseRecord[] = [
  {
    id: 'exp-2026-0801',
    expenseNo: 'EXP-2026-0801',
    date: '2026-08-21',
    category: 'Rent',
    title: 'Shop Monthly Rent (દુકાન ભાડું)',
    amount: 5500,
    paymentMode: 'Bank Transfer',
    paidTo: 'Gold Complex Owner',
    notes: 'August 2026 rent',
    createdAt: '2026-08-21T11:00:00.000Z'
  },
  {
    id: 'exp-2026-0802',
    expenseNo: 'EXP-2026-0802',
    date: '2026-08-23',
    category: 'Electricity',
    title: 'PGVCL Light Bill (લાઈટ બિલ)',
    amount: 1420,
    paymentMode: 'UPI',
    paidTo: 'PGVCL Electricity',
    notes: 'Workshop power consumption bill',
    createdAt: '2026-08-23T14:30:00.000Z'
  },
  {
    id: 'exp-2026-0803',
    expenseNo: 'EXP-2026-0803',
    date: '2026-08-25',
    category: 'Tea & Refreshment',
    title: 'Tea & Snacks Monthly (ચા-પાણી નાસ્તો)',
    amount: 650,
    paymentMode: 'Cash',
    paidTo: 'Radhe Tea Stall',
    notes: 'Workshop daily tea',
    createdAt: '2026-08-25T16:00:00.000Z'
  },
  {
    id: 'exp-2026-0804',
    expenseNo: 'EXP-2026-0804',
    date: '2026-08-25',
    category: 'Courier & Transport',
    title: 'Courier Charges for Ahmedabad Client Parts',
    amount: 280,
    paymentMode: 'Cash',
    paidTo: 'Maruti Courier',
    notes: 'Dispatched repaired handpieces to Ambica Ornaments',
    createdAt: '2026-08-25T17:15:00.000Z'
  },
  {
    id: 'exp-2026-0805',
    expenseNo: 'EXP-2026-0805',
    date: '2026-08-26',
    category: 'Salary',
    type: 'EXPENSE',
    title: 'Staff Salary - Ramesh Patel',
    amount: 5000,
    paymentMode: 'Bank Transfer',
    paidTo: 'Ramesh Patel',
    staffId: 'staff-1',
    staffName: 'Ramesh Patel',
    notes: 'Advance salary payout',
    createdAt: '2026-08-26T18:00:00.000Z'
  }
];

export const INITIAL_UNIT_MASTERS: UnitMasterItem[] = [
  {
    id: 'um-hp',
    name: 'Dental Handpiece (હાઈ સ્પીડ / લો સ્પીડ હેન્ડપીસ)',
    nameGu: 'ડેન્ટલ હેન્ડપીસ',
    category: 'Dental Equipment',
    codePrefix: 'HP',
    defaultServiceCharge: 200,
    defaultWarrantyDays: 30,
    commonIssues: ['No rotation / Stuck head', 'Water blockage', 'Bearing noise & vibration', 'Burr loose slipping'],
    active: true,
  },
  {
    id: 'um-mot',
    name: 'Micro-Motor (માઇક્રો મોટર હેન્ડપીસ)',
    nameGu: 'માઇક્રો મોટર',
    category: 'Jewellery & Lab Micro-Tools',
    codePrefix: 'MOT',
    defaultServiceCharge: 150,
    defaultWarrantyDays: 30,
    commonIssues: ['Carbon brush worn out', 'Cable wire cut', 'Excessive heating', 'Speed fluctuation'],
    active: true,
  },
  {
    id: 'um-marathon',
    name: 'Marathon Controller Unit (મેરેથોન કંટ્રોલર બોક્સ)',
    nameGu: 'મેરેથોન કંટ્રોલ બોક્સ',
    category: 'Electronic Controllers',
    codePrefix: 'CTRL',
    defaultServiceCharge: 250,
    defaultWarrantyDays: 30,
    commonIssues: ['MOSFET short / blown fuse', 'Foot pedal not activating', 'Speed dial potentiometer faulty'],
    active: true,
  },
  {
    id: 'um-scaler',
    name: 'Ultrasonic Scaler (અલ્ટ્રાસોનિક સ્કેલર)',
    nameGu: 'અલ્ટ્રાસોનિક સ્કેલર',
    category: 'Dental Equipment',
    codePrefix: 'USC',
    defaultServiceCharge: 300,
    defaultWarrantyDays: 45,
    commonIssues: ['Handpiece transducer weak', 'No vibration output', 'Water leakage from connector'],
    active: true,
  },
  {
    id: 'um-polisher',
    name: 'Induction Polishing Motor (પોલિશિંગ મોટર)',
    nameGu: 'પોલિશિંગ મોટર',
    category: 'Jewellery Machinery',
    codePrefix: 'POL',
    defaultServiceCharge: 350,
    defaultWarrantyDays: 30,
    commonIssues: ['Shaft bearing jamming', 'Capacitor weak', 'Switch sparking'],
    active: true,
  },
];

export const INITIAL_SUPPLIERS: SupplierClient[] = [
  {
    id: 'sup-royal',
    name: 'Royal Spares Rajkot',
    contactPerson: 'Mansukhbhai Patel',
    phone: '+91 98250 88991',
    city: 'Rajkot',
    address: 'Shop No. 4, Lati Plot Main Road, Rajkot - 360003',
    gstNumber: '24AABFR1234F1Z9',
    category: 'Spare Parts Distributor',
    notes: 'Main vendor for micro-bearings, cables, and carbon brushes',
  },
  {
    id: 'sup-microtools',
    name: 'Gujarat Micro-Tools Depot',
    contactPerson: 'Ketan Shah',
    phone: '+91 98980 55442',
    city: 'Ahmedabad',
    address: 'Relief Road, Near Electricity House, Ahmedabad - 380001',
    gstNumber: '24AAACD9876D1Z2',
    category: 'Dental & Precision Importer',
    notes: 'NSK & Marathon compatible original spare parts',
  },
  {
    id: 'sup-elec',
    name: 'Shreeji Electronics & Components',
    contactPerson: 'Nileshbhai Vora',
    phone: '+91 94260 33221',
    city: 'Rajkot',
    address: 'Dhebar Road, Opp. ST Stand, Rajkot - 360002',
    gstNumber: '24AAJFS4455K1Z8',
    category: 'Electronic Components',
    notes: 'MOSFETs, capacitors, potentiometers, foot switches, and transformers',
  },
];

export const INITIAL_STAFF: StaffMember[] = [
  {
    id: 'staff-1',
    name: 'Ramesh Patel',
    nameGu: 'રમેશ પટેલ',
    phone: '+91 98790 12345',
    role: 'Senior Handpiece Technician (સીનિયર ટેકનિશિયન)',
    salary: 18000,
    salaryType: 'Monthly',
    joiningDate: '2025-01-10',
    active: true,
    address: 'Mavdi Plot, Rajkot',
    notes: 'Lead repair specialist for high-speed dental handpieces & micro-motors',
    createdAt: '2025-01-10T10:00:00.000Z',
  },
  {
    id: 'staff-2',
    name: 'Haresh Parmar',
    nameGu: 'હરેશ પરમાર',
    phone: '+91 98245 67890',
    role: 'Electronics & Controller Specialist (ઇલેક્ટ્રોનિક્સ)',
    salary: 15000,
    salaryType: 'Monthly',
    joiningDate: '2025-06-01',
    active: true,
    address: 'Kothariya Road, Rajkot',
    notes: 'Marathon box PCB, MOSFETs, and foot pedal specialist',
    createdAt: '2025-06-01T10:00:00.000Z',
  },
  {
    id: 'staff-3',
    name: 'Bharat Vaghela',
    nameGu: 'ભરત વાઘેલા',
    phone: '+91 94080 34567',
    role: 'Assistant Technician / Helper (આસિસ્ટન્ટ કારીગર)',
    salary: 9500,
    salaryType: 'Monthly',
    joiningDate: '2026-01-15',
    active: true,
    address: 'Aji Dam Ring Road, Rajkot',
    notes: 'Cleaning, ultrasonic parts wash, bearing assembly & dispatch',
    createdAt: '2026-01-15T10:00:00.000Z',
  },
];



