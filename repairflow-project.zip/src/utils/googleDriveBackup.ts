export const DEFAULT_DRIVE_FOLDER_ID = '1yBB-tJOhLGh3d25vAN-AZlRfxWoOwR93';
export const DEFAULT_DRIVE_FOLDER_URL = 'https://drive.google.com/drive/folders/1yBB-tJOhLGh3d25vAN-AZlRfxWoOwR93';

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  createdTime: string;
  size?: string;
  webViewLink?: string;
}

/**
 * Uploads a JSON backup of all workshop data into the user's Google Drive folder.
 */
export async function uploadJsonBackupToDrive(
  data: Record<string, any>,
  accessToken: string,
  folderId: string = DEFAULT_DRIVE_FOLDER_ID
): Promise<{ id: string; name: string; webViewLink?: string }> {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `repairflow-backup-${timestamp}.json`;
  const boundary = '-------314159265358979323846';

  const metadata = {
    name: filename,
    parents: [folderId],
    description: 'RepairFlow Service & Billing Full Database Backup',
    mimeType: 'application/json',
  };

  const fileContent = JSON.stringify(data, null, 2);

  const multipartRequestBody =
    `\r\n--${boundary}\r\n` +
    `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
    `${JSON.stringify(metadata)}\r\n` +
    `--${boundary}\r\n` +
    `Content-Type: application/json\r\n\r\n` +
    `${fileContent}\r\n` +
    `--${boundary}--`;

  const response = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Google Drive upload failed (${response.status}): ${errorText}`);
  }

  return await response.json();
}

/**
 * Uploads the project source code (.zip) directly into the Google Drive folder.
 */
export async function uploadZipArchiveToDrive(
  accessToken: string,
  folderId: string = DEFAULT_DRIVE_FOLDER_ID
): Promise<{ id: string; name: string; webViewLink?: string }> {
  // Fetch the zip file generated in public
  const zipResponse = await fetch('/repairflow-project.zip');
  if (!zipResponse.ok) {
    throw new Error('Project source zip file was not found on the server.');
  }

  const zipBlob = await zipResponse.blob();
  const dateStr = new Date().toISOString().slice(0, 10);
  const filename = `repairflow-source-code-${dateStr}.zip`;
  const boundary = '-------314159265358979323846';

  const metadata = {
    name: filename,
    parents: [folderId],
    description: 'RepairFlow Full Source Code Project Archive (.ZIP)',
    mimeType: 'application/zip',
  };

  const metadataBlob = new Blob([JSON.stringify(metadata)], { type: 'application/json' });

  const formData = new FormData();
  formData.append('metadata', metadataBlob);
  formData.append('file', zipBlob);

  const response = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      body: formData,
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to upload zip archive to Google Drive (${response.status}): ${errorText}`);
  }

  return await response.json();
}

/**
 * Lists backups stored in the user's designated Google Drive folder.
 */
export async function listFilesInDriveFolder(
  accessToken: string,
  folderId: string = DEFAULT_DRIVE_FOLDER_ID
): Promise<DriveFileItem[]> {
  const query = `'${folderId}' in parents and trashed = false`;
  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
    query
  )}&fields=files(id,name,mimeType,createdTime,size,webViewLink)&orderBy=createdTime desc&pageSize=20`;

  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to list files from Google Drive (${response.status}): ${errorText}`);
  }

  const result = await response.json();
  return result.files || [];
}

/**
 * Fetches JSON content of a backup file from Google Drive for restoration.
 */
export async function downloadFileContentFromDrive(
  fileId: string,
  accessToken: string
): Promise<any> {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to download backup file (${response.status}): ${errorText}`);
  }

  return await response.json();
}
