import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch,
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType, testConnection } from '../firebase';
import {
  Invoice,
  CatalogItem,
  Customer,
  PaymentRecord,
  PurchaseRecord,
  ExpenseRecord,
  WorkshopSettings,
  UnitMasterItem,
  SupplierClient,
  StaffMember,
} from '../types';
import {
  saveInvoices,
  saveCatalog,
  saveCustomers,
  savePayments,
  savePurchases,
  saveExpenses,
  saveSettings,
  saveUnitMasters,
  saveSuppliers,
  saveStaffMembers,
} from './storage';

// Call connection test on boot as required by Firebase skill
testConnection();

export interface SyncStatus {
  isOnline: boolean;
  isSyncing: boolean;
  lastSyncedAt: Date | null;
  error: string | null;
}

// Collections
const COLLECTIONS = {
  INVOICES: 'invoices',
  CATALOG: 'catalog',
  CUSTOMERS: 'customers',
  PAYMENTS: 'payments',
  PURCHASES: 'purchases',
  EXPENSES: 'expenses',
  SETTINGS: 'settings',
  UNIT_MASTERS: 'unit_masters',
  SUPPLIERS: 'suppliers',
  STAFF: 'staff',
};

// 1. Invoices Cloud Sync
export async function syncInvoiceToCloud(invoice: Invoice): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.INVOICES, invoice.id);
    await setDoc(docRef, invoice, { merge: true });
  } catch (error) {
    console.warn('Error syncing invoice to cloud:', error);
  }
}

export async function deleteInvoiceFromCloud(invoiceId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.INVOICES, invoiceId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting invoice from cloud:', error);
  }
}

// 2. Catalog Cloud Sync
export async function syncCatalogItemToCloud(item: CatalogItem): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.CATALOG, item.id);
    await setDoc(docRef, item, { merge: true });
  } catch (error) {
    console.warn('Error syncing catalog item to cloud:', error);
  }
}

export async function deleteCatalogItemFromCloud(itemId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.CATALOG, itemId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting catalog item from cloud:', error);
  }
}

// 3. Customers Cloud Sync
export async function syncCustomerToCloud(customer: Customer): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.CUSTOMERS, customer.id);
    await setDoc(docRef, customer, { merge: true });
  } catch (error) {
    console.warn('Error syncing customer to cloud:', error);
  }
}

export async function deleteCustomerFromCloud(customerId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.CUSTOMERS, customerId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting customer from cloud:', error);
  }
}

// 4. Payments Cloud Sync
export async function syncPaymentToCloud(payment: PaymentRecord): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.PAYMENTS, payment.id);
    await setDoc(docRef, payment, { merge: true });
  } catch (error) {
    console.warn('Error syncing payment to cloud:', error);
  }
}

export async function deletePaymentFromCloud(paymentId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.PAYMENTS, paymentId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting payment from cloud:', error);
  }
}

// 5. Purchases Cloud Sync
export async function syncPurchaseToCloud(purchase: PurchaseRecord): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.PURCHASES, purchase.id);
    await setDoc(docRef, purchase, { merge: true });
  } catch (error) {
    console.warn('Error syncing purchase to cloud:', error);
  }
}

export async function deletePurchaseFromCloud(purchaseId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.PURCHASES, purchaseId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting purchase from cloud:', error);
  }
}

// 6. Expenses Cloud Sync
export async function syncExpenseToCloud(expense: ExpenseRecord): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.EXPENSES, expense.id);
    await setDoc(docRef, expense, { merge: true });
  } catch (error) {
    console.warn('Error syncing expense to cloud:', error);
  }
}

export async function deleteExpenseFromCloud(expenseId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.EXPENSES, expenseId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting expense from cloud:', error);
  }
}

// 7. Settings Cloud Sync
export async function syncSettingsToCloud(settings: WorkshopSettings): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.SETTINGS, 'global');
    await setDoc(docRef, settings, { merge: true });
  } catch (error) {
    console.warn('Error syncing settings to cloud:', error);
  }
}

// 8. Unit Masters Cloud Sync
export async function syncUnitMasterToCloud(unit: UnitMasterItem): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.UNIT_MASTERS, unit.id);
    await setDoc(docRef, unit, { merge: true });
  } catch (error) {
    console.warn('Error syncing unit master to cloud:', error);
  }
}

export async function deleteUnitMasterFromCloud(unitId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.UNIT_MASTERS, unitId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting unit master from cloud:', error);
  }
}

// 9. Suppliers Cloud Sync
export async function syncSupplierToCloud(supplier: SupplierClient): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.SUPPLIERS, supplier.id);
    await setDoc(docRef, supplier, { merge: true });
  } catch (error) {
    console.warn('Error syncing supplier to cloud:', error);
  }
}

export async function deleteSupplierFromCloud(supplierId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.SUPPLIERS, supplierId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting supplier from cloud:', error);
  }
}

// 10. Staff Members Cloud Sync
export async function syncStaffMemberToCloud(staff: StaffMember): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.STAFF, staff.id);
    await setDoc(docRef, staff, { merge: true });
  } catch (error) {
    console.warn('Error syncing staff member to cloud:', error);
  }
}

export async function deleteStaffMemberFromCloud(staffId: string): Promise<void> {
  try {
    const docRef = doc(db, COLLECTIONS.STAFF, staffId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting staff member from cloud:', error);
  }
}

/**
 * Uploads initial local data to Firestore if cloud collection is empty.
 * This ensures new devices immediately get existing records on first sync.
 */
export async function seedLocalDataToCloudIfEmpty(initialData: {
  invoices: Invoice[];
  catalog: CatalogItem[];
  customers: Customer[];
  payments: PaymentRecord[];
  purchases: PurchaseRecord[];
  expenses: ExpenseRecord[];
  settings: WorkshopSettings;
  unitMasters: UnitMasterItem[];
  suppliers: SupplierClient[];
  staffMembers?: StaffMember[];
}) {
  try {
    const invoicesSnap = await getDocs(collection(db, COLLECTIONS.INVOICES));
    if (invoicesSnap.empty && initialData.invoices.length > 0) {
      console.log('Seeding initial invoices to Firestore...');
      for (const inv of initialData.invoices) {
        await syncInvoiceToCloud(inv);
      }
    }

    const catalogSnap = await getDocs(collection(db, COLLECTIONS.CATALOG));
    if (catalogSnap.empty && initialData.catalog.length > 0) {
      console.log('Seeding initial catalog to Firestore...');
      for (const item of initialData.catalog) {
        await syncCatalogItemToCloud(item);
      }
    }

    const customersSnap = await getDocs(collection(db, COLLECTIONS.CUSTOMERS));
    if (customersSnap.empty && initialData.customers.length > 0) {
      console.log('Seeding initial customers to Firestore...');
      for (const cust of initialData.customers) {
        await syncCustomerToCloud(cust);
      }
    }

    const unitMastersSnap = await getDocs(collection(db, COLLECTIONS.UNIT_MASTERS));
    if (unitMastersSnap.empty && initialData.unitMasters.length > 0) {
      for (const u of initialData.unitMasters) {
        await syncUnitMasterToCloud(u);
      }
    }

    const suppliersSnap = await getDocs(collection(db, COLLECTIONS.SUPPLIERS));
    if (suppliersSnap.empty && initialData.suppliers.length > 0) {
      for (const s of initialData.suppliers) {
        await syncSupplierToCloud(s);
      }
    }

    if (initialData.staffMembers && initialData.staffMembers.length > 0) {
      const staffSnap = await getDocs(collection(db, COLLECTIONS.STAFF));
      if (staffSnap.empty) {
        for (const sm of initialData.staffMembers) {
          await syncStaffMemberToCloud(sm);
        }
      }
    }

    await syncSettingsToCloud(initialData.settings);
  } catch (err) {
    console.warn('Could not seed initial data to cloud:', err);
  }
}

/**
 * Subscribe to real-time changes across all workshop collections.
 * Updates local storage & React state simultaneously.
 */
export function setupRealtimeSync(handlers: {
  onInvoices: (invoices: Invoice[]) => void;
  onCatalog: (catalog: CatalogItem[]) => void;
  onCustomers: (customers: Customer[]) => void;
  onPayments: (payments: PaymentRecord[]) => void;
  onPurchases: (purchases: PurchaseRecord[]) => void;
  onExpenses: (expenses: ExpenseRecord[]) => void;
  onSettings: (settings: WorkshopSettings) => void;
  onUnitMasters: (unitMasters: UnitMasterItem[]) => void;
  onSuppliers: (suppliers: SupplierClient[]) => void;
  onStaffMembers?: (staffMembers: StaffMember[]) => void;
  onStatusChange?: (status: SyncStatus) => void;
}) {
  const unsubs: (() => void)[] = [];

  // Invoices listener
  const unsubInvoices = onSnapshot(
    collection(db, COLLECTIONS.INVOICES),
    (snapshot) => {
      if (!snapshot.empty) {
        const cloudInvoices = snapshot.docs.map((doc) => doc.data() as Invoice);
        // Sort by date / createdAt desc
        cloudInvoices.sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());
        saveInvoices(cloudInvoices);
        handlers.onInvoices(cloudInvoices);
      }
      handlers.onStatusChange?.({
        isOnline: true,
        isSyncing: false,
        lastSyncedAt: new Date(),
        error: null,
      });
    },
    (err) => {
      console.warn('Invoices sync snapshot notice:', err);
      handlers.onStatusChange?.({
        isOnline: navigator.onLine,
        isSyncing: false,
        lastSyncedAt: null,
        error: err.message,
      });
    }
  );
  unsubs.push(unsubInvoices);

  // Catalog listener
  const unsubCatalog = onSnapshot(
    collection(db, COLLECTIONS.CATALOG),
    (snapshot) => {
      if (!snapshot.empty) {
        const cloudCatalog = snapshot.docs.map((doc) => doc.data() as CatalogItem);
        saveCatalog(cloudCatalog);
        handlers.onCatalog(cloudCatalog);
      }
    },
    (err) => console.warn('Catalog snapshot notice:', err)
  );
  unsubs.push(unsubCatalog);

  // Customers listener
  const unsubCustomers = onSnapshot(
    collection(db, COLLECTIONS.CUSTOMERS),
    (snapshot) => {
      if (!snapshot.empty) {
        const cloudCustomers = snapshot.docs.map((doc) => doc.data() as Customer);
        saveCustomers(cloudCustomers);
        handlers.onCustomers(cloudCustomers);
      }
    },
    (err) => console.warn('Customers snapshot notice:', err)
  );
  unsubs.push(unsubCustomers);

  // Payments listener
  const unsubPayments = onSnapshot(
    collection(db, COLLECTIONS.PAYMENTS),
    (snapshot) => {
      if (!snapshot.empty) {
        const cloudPayments = snapshot.docs.map((doc) => doc.data() as PaymentRecord);
        cloudPayments.sort((a, b) => new Date(b.date || b.createdAt || '').getTime() - new Date(a.date || a.createdAt || '').getTime());
        savePayments(cloudPayments);
        handlers.onPayments(cloudPayments);
      }
    },
    (err) => console.warn('Payments snapshot notice:', err)
  );
  unsubs.push(unsubPayments);

  // Purchases listener
  const unsubPurchases = onSnapshot(
    collection(db, COLLECTIONS.PURCHASES),
    (snapshot) => {
      if (!snapshot.empty) {
        const cloudPurchases = snapshot.docs.map((doc) => doc.data() as PurchaseRecord);
        cloudPurchases.sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());
        savePurchases(cloudPurchases);
        handlers.onPurchases(cloudPurchases);
      }
    },
    (err) => console.warn('Purchases snapshot notice:', err)
  );
  unsubs.push(unsubPurchases);

  // Expenses listener
  const unsubExpenses = onSnapshot(
    collection(db, COLLECTIONS.EXPENSES),
    (snapshot) => {
      if (!snapshot.empty) {
        const cloudExpenses = snapshot.docs.map((doc) => doc.data() as ExpenseRecord);
        cloudExpenses.sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());
        saveExpenses(cloudExpenses);
        handlers.onExpenses(cloudExpenses);
      }
    },
    (err) => console.warn('Expenses snapshot notice:', err)
  );
  unsubs.push(unsubExpenses);

  // Settings listener
  const unsubSettings = onSnapshot(
    doc(db, COLLECTIONS.SETTINGS, 'global'),
    (snapshot) => {
      if (snapshot.exists()) {
        const cloudSettings = snapshot.data() as WorkshopSettings;
        saveSettings(cloudSettings);
        handlers.onSettings(cloudSettings);
      }
    },
    (err) => console.warn('Settings snapshot notice:', err)
  );
  unsubs.push(unsubSettings);

  // Unit Masters listener
  const unsubUnitMasters = onSnapshot(
    collection(db, COLLECTIONS.UNIT_MASTERS),
    (snapshot) => {
      if (!snapshot.empty) {
        const cloudUnitMasters = snapshot.docs.map((doc) => doc.data() as UnitMasterItem);
        saveUnitMasters(cloudUnitMasters);
        handlers.onUnitMasters(cloudUnitMasters);
      }
    },
    (err) => console.warn('Unit Masters snapshot notice:', err)
  );
  unsubs.push(unsubUnitMasters);

  // Suppliers listener
  const unsubSuppliers = onSnapshot(
    collection(db, COLLECTIONS.SUPPLIERS),
    (snapshot) => {
      if (!snapshot.empty) {
        const cloudSuppliers = snapshot.docs.map((doc) => doc.data() as SupplierClient);
        saveSuppliers(cloudSuppliers);
        handlers.onSuppliers(cloudSuppliers);
      }
    },
    (err) => console.warn('Suppliers snapshot notice:', err)
  );
  unsubs.push(unsubSuppliers);

  // Staff listener
  const unsubStaff = onSnapshot(
    collection(db, COLLECTIONS.STAFF),
    (snapshot) => {
      if (!snapshot.empty && handlers.onStaffMembers) {
        const cloudStaff = snapshot.docs.map((doc) => doc.data() as StaffMember);
        saveStaffMembers(cloudStaff);
        handlers.onStaffMembers(cloudStaff);
      }
    },
    (err) => console.warn('Staff snapshot notice:', err)
  );
  unsubs.push(unsubStaff);

  return () => {
    unsubs.forEach((unsub) => unsub());
  };
}
