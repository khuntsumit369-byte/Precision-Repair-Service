import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const publicDir = path.join(rootDir, 'public');

const zip = new JSZip();

const IGNORED_NAMES = new Set([
  'node_modules',
  '.git',
  'dist',
  '.cache',
  'repairflow-project.zip',
  'project-source.zip',
]);

function shouldIgnore(name, fullPath) {
  if (IGNORED_NAMES.has(name)) return true;
  if (name.endsWith('.zip')) return true;
  if (name.startsWith('.tmp')) return true;
  return false;
}

function addDirectoryToZip(dirPath, zipFolder) {
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    if (shouldIgnore(entry.name, fullPath)) continue;

    if (entry.isDirectory()) {
      const nestedFolder = zipFolder.folder(entry.name);
      addDirectoryToZip(fullPath, nestedFolder);
    } else if (entry.isFile()) {
      const fileData = fs.readFileSync(fullPath);
      zipFolder.file(entry.name, fileData);
    }
  }
}

async function main() {
  console.log('Packing project into zip...');
  const projectFolder = zip.folder('repairflow-billing-app');
  addDirectoryToZip(rootDir, projectFolder);

  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  const content = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const outputPath = path.join(publicDir, 'repairflow-project.zip');
  fs.writeFileSync(outputPath, content);
  console.log(`Zip successfully created at: ${outputPath} (${(content.length / (1024 * 1024)).toFixed(2)} MB)`);
}

main().catch((err) => {
  console.error('Failed to create zip:', err);
  process.exit(1);
});
